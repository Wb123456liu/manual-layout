# AI 手册排版工具 v2.1

基于 Flask 的智能手册排版系统，参考施耐德电气产品手册专业标准。

## 🆕 v2.1 新增功能

### 步骤0：文档设置
- 文档编号自动生成
- 版本管理（v1.0, v1.1, v2.0）
- 公司Logo上传
- 安全标识配置
- 页眉页脚设置
- 多语言支持（中/英/双语）

### 封面自动生成
- Logo + 产品名称 + 型号 + 日期
- 自定义封面背景
- 产品图片插入

### 目录自动生成
- 从章节结构自动生成
- 自动计算页码
- 多级目录支持

### 法律信息页模板
- 商标声明
- 版权声明
- 免责声明
- 支持自定义文本

### 安全标识系统
| 级别 | 颜色 | 说明 |
|-----|------|------|
| DANGER | 红色 | 危险 - 不避免将导致死亡或重伤 |
| WARNING | 橙色 | 警告 - 不避免可能导致死亡或重伤 |
| CAUTION | 黄色 | 注意 - 不避免可能导致伤害或设备损坏 |
| NOTICE | 蓝色 | 提示 - 不遵守可能导致设备损坏 |

### 章节自动编号
- 1.1, 1.2, 2.1 自动编号
- 与目录自动同步

### 页眉页脚
- 自动插入每页
- 支持模板配置

## 5 步向导流程

```
步骤0(文档设置) → 步骤1(模板选择) → 步骤2(导入手册) → 步骤3(智能排版) → 步骤4(手册输出)
```

## 快速部署

### Render 部署
1. Fork 本仓库
2. 在 Render 创建新的 Web Service
3. 连接 GitHub 仓库
4. 自动检测 `render.yaml` 配置
5. 点击部署

### 本地运行
```bash
pip install -r requirements.txt
python app.py
```
访问 http://localhost:5000

## API 接口

### 步骤0：文档设置
| 接口 | 方法 | 说明 |
|-----|------|------|
| `/api/settings/create` | POST | 创建文档设置 |
| `/api/settings/get` | GET | 获取文档设置 |
| `/api/settings/generate_doc_number` | POST | 生成文档编号 |

### 封面/法律页/目录
| 接口 | 方法 | 说明 |
|-----|------|------|
| `/api/cover/generate` | POST | 生成封面 |
| `/api/legal/generate` | POST | 生成法律信息页 |
| `/api/toc/generate` | POST | 生成目录 |

### 安全标识
| 接口 | 方法 | 说明 |
|-----|------|------|
| `/api/safety/levels` | GET | 获取安全标识级别 |
| `/api/safety/apply` | POST | 应用安全标识 |
| `/api/safety/detect` | POST | 检测安全标识 |

### 文档处理
| 接口 | 方法 | 说明 |
|-----|------|------|
| `/api/import/feishu` | POST | 导入飞书文档 |
| `/api/import/file` | POST | 导入本地文件 |
| `/api/layout/smart` | POST | 智能排版 |
| `/api/export/pdf` | POST | 导出PDF |
| `/api/export/word` | POST | 导出Word |

## 文件结构

```
ai-manual-tool-deploy/
├── app.py              # Flask 后端 (v2.1)
├── requirements.txt    # Python 依赖
├── render.yaml         # Render 部署配置
├── README.md           # 说明文档
└── templates/
    └── index.html      # 前端界面
```

## 飞书配置

在 `app.py` 中修改：
```python
APP_ID = "your_app_id"
APP_SECRET = "your_app_secret"
```

## License

MIT