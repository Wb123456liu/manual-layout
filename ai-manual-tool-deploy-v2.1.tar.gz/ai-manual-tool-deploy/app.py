#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI手册排版工具 - 后端服务 v2.1
功能：飞书文档导入、Word/PDF解析、智能排版、导出发布
新增：文档设置、封面生成、目录生成、法律信息页、安全标识系统、章节编号、页眉页脚
"""

from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
import requests
import base64
import json
import os
import re
import tempfile
from datetime import datetime

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 上传限制
app.config['UPLOAD_FOLDER'] = tempfile.gettempdir()

# 飞书应用配置
APP_ID = "cli_a93ba972e5b9dbc9"
APP_SECRET = "Q7dozSDn3gdGsdKO8YfzzIfasQjtRyzDU"

# 缓存
TOKEN_CACHE = {"token": None, "expire": 0}
VERSIONS = {}  # 版本管理
DOC_SETTINGS = {}  # 文档设置缓存

# ========== 安全标识系统 ==========

SAFETY_LEVELS = {
    "DANGER": {
        "color": "#FF0000",
        "icon": "⚠️",
        "border": "solid 3px",
        "description": "危险 - 不避免将导致死亡或重伤",
        "bg_color": "#FF000020"
    },
    "WARNING": {
        "color": "#FF8C00",
        "icon": "⚡",
        "border": "solid 2px",
        "description": "警告 - 不避免可能导致死亡或重伤",
        "bg_color": "#FF8C0020"
    },
    "CAUTION": {
        "color": "#FFD700",
        "icon": "⚠",
        "border": "solid 1px",
        "description": "注意 - 不避免可能导致伤害或设备损坏",
        "bg_color": "#FFD70020"
    },
    "NOTICE": {
        "color": "#1E90FF",
        "icon": "ℹ️",
        "border": "solid 1px",
        "description": "提示 - 不遵守可能导致设备损坏",
        "bg_color": "#1E90FF20"
    }
}

def apply_safety_label(text, level):
    """应用安全标识"""
    config = SAFETY_LEVELS.get(level, SAFETY_LEVELS["NOTICE"])
    return f"""<div style="border: {config['border']} {config['color']}; padding: 15px; margin: 15px 0; background: {config['bg_color']}; border-radius: 5px;">
    <strong style="color: {config['color']}; font-size: 14px;">{config['icon']} {level}</strong>
    <p style="margin-top: 10px; margin-bottom: 0;">{text}</p>
</div>"""

def detect_safety_labels(text):
    """检测并转换安全标识"""
    patterns = [
        (r'DANGER[:：]\s*(.+?)(?=\n\n|\n[A-Z]|$)', "DANGER"),
        (r'WARNING[:：]\s*(.+?)(?=\n\n|\n[A-Z]|$)', "WARNING"),
        (r'CAUTION[:：]\s*(.+?)(?=\n\n|\n[A-Z]|$)', "CAUTION"),
        (r'NOTICE[:：]\s*(.+?)(?=\n\n|\n[A-Z]|$)', "NOTICE"),
        (r'危险[:：]\s*(.+?)(?=\n\n|\n[危险警告注意提示]|$)', "DANGER"),
        (r'警告[:：]\s*(.+?)(?=\n\n|\n[危险警告注意提示]|$)', "WARNING"),
        (r'注意[:：]\s*(.+?)(?=\n\n|\n[危险警告注意提示]|$)', "CAUTION"),
        (r'提示[:：]\s*(.+?)(?=\n\n|\n[危险警告注意提示]|$)', "NOTICE"),
    ]
    
    result = text
    for pattern, level in patterns:
        matches = re.findall(pattern, result, re.DOTALL | re.IGNORECASE)
        for match in matches:
            original = f"{level}：{match}" if level.isupper() else f"{level}：{match}"
            result = result.replace(original, apply_safety_label(match.strip(), level))
    
    return result

# ========== 飞书 API ==========

def get_tenant_access_token():
    """获取 tenant_access_token"""
    import time
    
    if TOKEN_CACHE["token"] and TOKEN_CACHE["expire"] > time.time():
        return TOKEN_CACHE["token"]
    
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    
    resp = requests.post(url, json=data)
    result = resp.json()
    
    if result.get("code") == 0:
        TOKEN_CACHE["token"] = result["tenant_access_token"]
        TOKEN_CACHE["expire"] = time.time() + result["expire"] - 60
        return TOKEN_CACHE["token"]
    return None

def feishu_api(path, method="GET", data=None):
    """通用飞书 API 调用"""
    token = get_tenant_access_token()
    if not token:
        return None, "获取token失败"
    
    headers = {"Authorization": f"Bearer {token}"}
    url = f"https://open.feishu.cn/open-apis/{path}"
    
    if method == "GET":
        resp = requests.get(url, headers=headers)
    else:
        resp = requests.post(url, headers=headers, json=data)
    
    result = resp.json()
    if result.get("code") == 0:
        return result.get("data"), None
    return None, result.get("msg")

# ========== 文档解析 ==========

def parse_docx(file_path):
    """解析 Word 文档"""
    try:
        import mammoth
        with open(file_path, "rb") as f:
            result = mammoth.extract_raw_text(f)
            text = result.value
        
        images = []
        with open(file_path, "rb") as f:
            img_result = mammoth.convert_to_html(f)
            img_matches = re.findall(r'src="([^"]+)"', img_result.value)
            images = [img for img in img_matches if img.startswith('data:')]
        
        return {"text": text, "images": images, "error": None}
    except Exception as e:
        return {"text": "", "images": [], "error": str(e)}

def parse_pdf(file_path):
    """解析 PDF 文档"""
    try:
        import fitz
        doc = fitz.open(file_path)
        text = ""
        images = []
        
        for page in doc:
            text += page.get_text() + "\n\n"
            for img in page.get_images():
                xref = img[0]
                pix = fitz.Pixmap(doc, xref)
                if pix.n < 5:
                    img_data = pix.tobytes("png")
                    img_base64 = base64.b64encode(img_data).decode()
                    images.append(f"data:image/png;base64,{img_base64}")
        
        doc.close()
        return {"text": text, "images": images, "error": None}
    except Exception as e:
        return {"text": "", "images": [], "error": str(e)}

def parse_txt(file_path):
    """解析文本文件"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
        return {"text": text, "images": [], "error": None}
    except Exception as e:
        return {"text": "", "images": [], "error": str(e)}

# ========== 步骤0：文档设置 ==========

def generate_doc_number(product_code, lang="CN"):
    """生成文档编号"""
    date_str = datetime.now().strftime("%Y%m")
    return f"{product_code}-01_{lang}"

def create_document_settings(settings):
    """创建文档设置"""
    doc_id = settings.get('doc_id', generate_doc_number(settings.get('product_code', 'MANUAL')))
    
    DOC_SETTINGS[doc_id] = {
        "doc_number": settings.get('doc_number', doc_id),
        "version": settings.get('version', 'v1.0'),
        "date": settings.get('date', datetime.now().strftime("%Y-%m")),
        "product_name": settings.get('product_name', ''),
        "product_code": settings.get('product_code', ''),
        "company_name": settings.get('company_name', ''),
        "company_url": settings.get('company_url', ''),
        "logo": settings.get('logo', ''),
        "language": settings.get('language', 'CN'),
        "safety_labels_enabled": settings.get('safety_labels_enabled', True),
        "header_template": settings.get('header_template', '{doc_number} | {product_name}'),
        "footer_template": settings.get('footer_template', '{company_name} | 第 {page} 页'),
        "created_at": datetime.now().isoformat()
    }
    
    return DOC_SETTINGS[doc_id]

# ========== 封面生成 ==========

def generate_cover(settings):
    """生成封面HTML"""
    return f"""<div style="text-align: center; padding: 50mm 20mm; page-break-after: always;">
    <div style="margin-bottom: 30mm;">
        {f'<img src="{settings.get("logo")}" style="max-width: 80mm; max-height: 30mm;">' if settings.get('logo') else ''}
    </div>
    <h1 style="font-size: 28pt; color: #0066cc; margin-bottom: 15mm;">{settings.get('product_name', '产品手册')}</h1>
    <h2 style="font-size: 18pt; color: #666; margin-bottom: 20mm;">{settings.get('product_code', '')}</h2>
    <div style="font-size: 12pt; color: #999;">
        <p>文档编号：{settings.get('doc_number', '')}</p>
        <p>版本：{settings.get('version', 'v1.0')}</p>
        <p>发布日期：{settings.get('date', '')}</p>
    </div>
    <div style="margin-top: 40mm; font-size: 10pt; color: #999;">
        <p>{settings.get('company_name', '')}</p>
        {f'<p>{settings.get("company_url", "")}</p>' if settings.get('company_url') else ''}
    </div>
</div>"""

# ========== 法律信息页 ==========

def generate_legal_page(company_name="施耐德电气"):
    """生成法律信息页"""
    return f"""<div style="page-break-after: always; padding: 20mm;">
    <h1 style="color: #0066cc; border-bottom: 2px solid #0066cc; padding-bottom: 5mm;">法律信息</h1>
    
    <h2 style="margin-top: 10mm;">商标声明</h2>
    <p style="line-height: 1.8;">{company_name}品牌及本指南中提及的{company_name} SE及其子公司的任何商标均为{company_name} SE或其子公司的财产。所有其他品牌可能为其各自所有者的商标。</p>
    
    <h2 style="margin-top: 10mm;">版权声明</h2>
    <p style="line-height: 1.8;">本指南及其内容受适用版权法保护，仅供信息参考使用。未经{company_name}事先书面许可，不得以任何形式或任何方式（电子、机械、影印、录制或其他方式）复制或传播本指南的任何部分用于任何目的。</p>
    
    <h2 style="margin-top: 10mm;">免责声明</h2>
    <p style="line-height: 1.8;">在适用法律允许的范围内，{company_name}及其子公司不对本材料信息内容中的任何错误或遗漏承担任何责任或义务，也不对使用本文所含信息产生的后果承担任何责任或义务。</p>
    
    <p style="margin-top: 15mm; font-size: 9pt; color: #999;">本文档由AI手册排版工具自动生成</p>
</div>"""

# ========== 目录生成 ==========

def generate_toc_html(toc_items):
    """生成目录HTML"""
    toc_html = """<div style="page-break-after: always; padding: 20mm;">
    <h1 style="color: #0066cc; border-bottom: 2px solid #0066cc; padding-bottom: 5mm;">目录</h1>
    <div style="margin-top: 10mm;">"""
    
    for item in toc_items:
        level = item.get('level', 1)
        title = item.get('title', '')
        page = item.get('page', 1)
        indent = (level - 1) * 5
        
        toc_html += f"""<div style="margin-left: {indent}mm; margin-bottom: 3mm; display: flex; justify-content: space-between;">
        <span style="font-size: {12 - level}pt;">{title}</span>
        <span style="font-size: {12 - level}pt;">{page}</span>
    </div>"""
    
    toc_html += """</div>
</div>"""
    
    return toc_html

def generate_toc(text):
    """从文本生成目录结构"""
    toc = []
    chapter_num = 0
    section_num = 0
    
    lines = text.split('\n')
    for i, line in enumerate(lines):
        line = line.strip()
        
        # 章标题
        if re.match(r'^第[一二三四五六七八九十]+[章节部]', line) or re.match(r'^#\s', line):
            chapter_num += 1
            section_num = 0
            title = re.sub(r'^#\s', '', line)
            toc.append({"level": 1, "title": title, "line": i + 1, "page": i // 40 + 1})
        # 节标题
        elif re.match(r'^##\s', line) or re.match(r'^[一二三四五六七八九十]+[、.]', line):
            section_num += 1
            title = re.sub(r'^##\s', '', line)
            toc.append({"level": 2, "title": title, "line": i + 1, "page": i // 40 + 1})
        # 小节标题
        elif re.match(r'^###\s', line):
            title = re.sub(r'^###\s', '', line)
            toc.append({"level": 3, "title": title, "line": i + 1, "page": i // 40 + 1})
    
    return toc

# ========== 章节编号 ==========

def add_chapter_numbers(text):
    """添加章节编号"""
    lines = text.split('\n')
    result = []
    chapter_num = 0
    section_num = 0
    subsection_num = 0
    
    for line in lines:
        stripped = line.strip()
        
        # 一级标题（章）
        if stripped.startswith('# ') and not stripped.startswith('# '):
            chapter_num += 1
            section_num = 0
            subsection_num = 0
            title = stripped[2:]
            result.append(f"# {chapter_num}. {title}")
        # 二级标题（节）
        elif stripped.startswith('## '):
            section_num += 1
            subsection_num = 0
            title = stripped[3:]
            result.append(f"## {chapter_num}.{section_num} {title}")
        # 三级标题（小节）
        elif stripped.startswith('### '):
            subsection_num += 1
            title = stripped[4:]
            result.append(f"### {chapter_num}.{section_num}.{subsection_num} {title}")
        else:
            result.append(line)
    
    return '\n'.join(result)

# ========== 页眉页脚 ==========

def add_header_footer(html, settings, page_num=1):
    """添加页眉页脚"""
    header = settings.get('header_template', '{doc_number}').format(
        doc_number=settings.get('doc_number', ''),
        product_name=settings.get('product_name', ''),
        page=page_num
    )
    
    footer = settings.get('footer_template', '第 {page} 页').format(
        company_name=settings.get('company_name', ''),
        page=page_num
    )
    
    return f"""<div style="position: running(header);">
    <div style="text-align: center; font-size: 9pt; color: #999; border-bottom: 1px solid #ddd; padding-bottom: 3mm;">
        {header}
    </div>
</div>
{html}
<div style="position: running(footer);">
    <div style="text-align: center; font-size: 9pt; color: #999; border-top: 1px solid #ddd; padding-top: 3mm;">
        {footer}
    </div>
</div>"""

# ========== AI 智能排版 ==========

def smart_layout(text, settings=None):
    """智能排版处理"""
    lines = text.split('\n')
    processed = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # 标题识别
        if re.match(r'^第[一二三四五六七八九十]+[章节部]', line):
            processed.append(f"# {line}")
        elif re.match(r'^[一二三四五六七八九十]+[、.]', line):
            processed.append(f"## {line}")
        elif re.match(r'^\d+[\.\、]', line) and len(line) < 50:
            processed.append(f"### {line}")
        # 列表识别
        elif re.match(r'^[-*•]\s', line):
            processed.append(line)
        elif re.match(r'^\d+\)\s', line):
            processed.append(f"- {line[3:]}")
        else:
            processed.append(line)
    
    result = '\n'.join(processed)
    
    # 添加章节编号
    result = add_chapter_numbers(result)
    
    # 安全标识检测
    if settings and settings.get('safety_labels_enabled', True):
        result = detect_safety_labels(result)
    
    return result

# ========== 路由 ==========

@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

# ========== 步骤0：文档设置 API ==========

@app.route('/api/settings/create', methods=['POST'])
def settings_create():
    """创建文档设置"""
    settings = request.json
    result = create_document_settings(settings)
    return jsonify({"success": True, "settings": result})

@app.route('/api/settings/get', methods=['GET'])
def settings_get():
    """获取文档设置"""
    doc_id = request.args.get('doc_id')
    if doc_id and doc_id in DOC_SETTINGS:
        return jsonify({"settings": DOC_SETTINGS[doc_id]})
    return jsonify({"settings": None})

@app.route('/api/settings/generate_doc_number', methods=['POST'])
def settings_generate_doc_number():
    """生成文档编号"""
    product_code = request.json.get('product_code', 'MANUAL')
    lang = request.json.get('lang', 'CN')
    doc_number = generate_doc_number(product_code, lang)
    return jsonify({"doc_number": doc_number})

# ========== 封面生成 API ==========

@app.route('/api/cover/generate', methods=['POST'])
def cover_generate():
    """生成封面"""
    settings = request.json
    cover_html = generate_cover(settings)
    return jsonify({"html": cover_html})

# ========== 法律信息页 API ==========

@app.route('/api/legal/generate', methods=['POST'])
def legal_generate():
    """生成法律信息页"""
    company_name = request.json.get('company_name', '施耐德电气')
    legal_html = generate_legal_page(company_name)
    return jsonify({"html": legal_html})

# ========== 目录生成 API ==========

@app.route('/api/toc/generate', methods=['POST'])
def toc_generate():
    """生成目录"""
    text = request.json.get('text', '')
    toc = generate_toc(text)
    toc_html = generate_toc_html(toc)
    return jsonify({"toc": toc, "html": toc_html})

# ========== 安全标识 API ==========

@app.route('/api/safety/levels', methods=['GET'])
def safety_levels():
    """获取安全标识级别"""
    return jsonify({"levels": SAFETY_LEVELS})

@app.route('/api/safety/apply', methods=['POST'])
def safety_apply():
    """应用安全标识"""
    text = request.json.get('text', '')
    level = request.json.get('level', 'NOTICE')
    result = apply_safety_label(text, level)
    return jsonify({"html": result})

@app.route('/api/safety/detect', methods=['POST'])
def safety_detect():
    """检测安全标识"""
    text = request.json.get('text', '')
    result = detect_safety_labels(text)
    return jsonify({"text": result})

# ========== 文档导入 API ==========

@app.route('/api/import/feishu', methods=['POST'])
def import_feishu():
    """导入飞书文档"""
    data = request.json
    doc_id = data.get('doc_id')
    doc_type = data.get('doc_type', 'docx')
    
    if not doc_id:
        return jsonify({"error": "缺少文档ID"}), 400
    
    if doc_type == "docx":
        path = f"docx/v1/documents/{doc_id}/raw_content"
    else:
        path = f"docs/{doc_id}/raw_content"
    
    result, error = feishu_api(path)
    if error:
        return jsonify({"error": error}), 400
    
    content = result.get("content", "") if result else ""
    
    # 获取文档设置
    settings = DOC_SETTINGS.get(doc_id, {})
    
    # 智能排版
    processed = smart_layout(content, settings)
    toc = generate_toc(processed)
    
    return jsonify({
        "content": processed,
        "toc": toc,
        "doc_id": doc_id,
        "stats": {
            "chars": len(content),
            "lines": len(content.split('\n')),
            "sections": len(toc)
        }
    })

@app.route('/api/import/file', methods=['POST'])
def import_file():
    """导入本地文件"""
    if 'file' not in request.files:
        return jsonify({"error": "未上传文件"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "未选择文件"}), 400
    
    filename = secure_filename(file.filename)
    ext = filename.rsplit('.', 1)[-1].lower()
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(file_path)
    
    if ext == 'docx':
        result = parse_docx(file_path)
    elif ext == 'pdf':
        result = parse_pdf(file_path)
    elif ext in ['txt', 'md']:
        result = parse_txt(file_path)
    else:
        os.remove(file_path)
        return jsonify({"error": f"不支持的文件格式: {ext}"}), 400
    
    os.remove(file_path)
    
    if result["error"]:
        return jsonify({"error": result["error"]}), 400
    
    # 智能排版
    processed = smart_layout(result["text"])
    toc = generate_toc(processed)
    
    return jsonify({
        "content": processed,
        "images": result["images"],
        "toc": toc,
        "stats": {
            "chars": len(result["text"]),
            "lines": len(result["text"].split('\n')),
            "sections": len(toc),
            "images": len(result["images"])
        }
    })

# ========== 智能排版 API ==========

@app.route('/api/layout/smart', methods=['POST'])
def layout_smart():
    """智能排版"""
    text = request.json.get('text', '')
    settings = request.json.get('settings', {})
    processed = smart_layout(text, settings)
    toc = generate_toc(processed)
    
    return jsonify({
        "content": processed,
        "toc": toc
    })

# ========== 版本管理 API ==========

@app.route('/api/version/save', methods=['POST'])
def version_save():
    """保存版本"""
    doc_id = request.json.get('doc_id', 'default')
    content = request.json.get('content', '')
    
    if doc_id not in VERSIONS:
        VERSIONS[doc_id] = []
    
    version = {
        "id": len(VERSIONS[doc_id]) + 1,
        "content": content,
        "time": datetime.now().isoformat(),
        "chars": len(content)
    }
    VERSIONS[doc_id].append(version)
    
    return jsonify({"version": version})

@app.route('/api/version/list', methods=['GET'])
def version_list():
    """版本列表"""
    doc_id = request.args.get('doc_id', 'default')
    versions = VERSIONS.get(doc_id, [])
    return jsonify({"versions": versions})

# ========== 导出 API ==========

@app.route('/api/export/pdf', methods=['POST'])
def export_pdf():
    """导出 PDF"""
    content = request.json.get('content', '')
    title = request.json.get('title', '产品手册')
    settings = request.json.get('settings', {})
    
    # 生成完整文档
    cover_html = generate_cover(settings) if settings else ''
    legal_html = generate_legal_page(settings.get('company_name', '施耐德电气')) if settings else ''
    toc = generate_toc(content)
    toc_html = generate_toc_html(toc)
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{title}</title>
    <style>
        @page {{ size: A4; margin: 15mm; }}
        body {{ font-family: "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; }}
        h1 {{ color: #0066cc; border-bottom: 2px solid #0066cc; padding-bottom: 5mm; }}
        h2 {{ color: #0066cc; margin-top: 8mm; }}
        h3 {{ color: #333; margin-top: 5mm; }}
    </style>
</head>
<body>
{cover_html}
{legal_html}
{toc_html}
<div style="padding: 20mm;">
{content}
</div>
</body>
</html>"""
    
    return jsonify({"html": html, "title": title})

@app.route('/api/export/word', methods=['POST'])
def export_word():
    """导出 Word"""
    content = request.json.get('content', '')
    title = request.json.get('title', '产品手册')
    
    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>{title}</title></head>
<body>
<h1>{title}</h1>
{content}
</body>
</html>"""
    
    return jsonify({"html": html, "title": title})

@app.route('/api/feishu/publish', methods=['POST'])
def feishu_publish():
    """发布到飞书"""
    content = request.json.get('content', '')
    title = request.json.get('title', '产品手册')
    folder_token = request.json.get('folder_token')
    
    data = {
        "title": title,
        "folder_token": folder_token
    }
    
    result, error = feishu_api("docx/v1/documents", "POST", data)
    if error:
        return jsonify({"error": error}), 400
    
    doc_id = result.get("document", {}).get("document_id")
    
    return jsonify({
        "doc_id": doc_id,
        "url": f"https://wbenergy.feishu.cn/docx/{doc_id}"
    })

if __name__ == '__main__':
    print("🚀 AI手册排版工具 v2.1 启动中...")
    print("📍 访问地址: http://localhost:5000")
    print("✨ 新增功能: 文档设置、封面生成、目录生成、法律信息页、安全标识系统、章节编号、页眉页脚")
    app.run(host='0.0.0.0', port=5000, debug=True)