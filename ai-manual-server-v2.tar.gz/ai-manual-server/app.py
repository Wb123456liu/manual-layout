#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI手册排版工具 - 后端服务 v2
功能：飞书文档导入、Word/PDF解析、智能排版、导出发布
"""

from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
import requests
import base64
import json
import os
import re
import tempfile
from datetime import datetime

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 上传限制
app.config['UPLOAD_FOLDER'] = tempfile.gettempdir()

# 飞书应用配置
APP_ID = "cli_a93ba972e5b9dbc9"
APP_SECRET = "Q7dozSDn3gdGsdKO8YfzIfasQjtRyzDU"

# 缓存
TOKEN_CACHE = {"token": None, "expire": 0}
VERSIONS = {}  # 版本管理

# ========== 飞书 API ==========

def get_tenant_access_token():
    """获取 tenant_access_token"""
    import time
    
    if TOKEN_CACHE["token"] and TOKEN_CACHE["expire"] > time.time():
        return TOKEN_CACHE["token"]
    
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    data = {"app_id": APP_ID, "app_secret": APP_SECRET}
    
    resp = requests.post(url, json=data)
    result = resp.json()
    
    if result.get("code") == 0:
        TOKEN_CACHE["token"] = result["tenant_access_token"]
        TOKEN_CACHE["expire"] = time.time() + result["expire"] - 60
        return TOKEN_CACHE["token"]
    return None

def feishu_api(path, method="GET", data=None):
    """通用飞书 API 调用"""
    token = get_tenant_access_token()
    if not token:
        return None, "获取token失败"
    
    headers = {"Authorization": f"Bearer {token}"}
    url = f"https://open.feishu.cn/open-apis/{path}"
    
    if method == "GET":
        resp = requests.get(url, headers=headers)
    else:
        resp = requests.post(url, headers=headers, json=data)
    
    result = resp.json()
    if result.get("code") == 0:
        return result.get("data"), None
    return None, result.get("msg")

# ========== 文档解析 ==========

def parse_docx(file_path):
    """解析 Word 文档"""
    try:
        import mammoth
        with open(file_path, "rb") as f:
            result = mammoth.extract_raw_text(f)
            text = result.value
        
        # 提取图片
        images = []
        with open(file_path, "rb") as f:
            img_result = mammoth.convert_to_html(f)
            # 从 HTML 中提取图片
            img_matches = re.findall(r'src="([^"]+)"', img_result.value)
            images = [img for img in img_matches if img.startswith('data:')]
        
        return {"text": text, "images": images, "error": None}
    except Exception as e:
        return {"text": "", "images": [], "error": str(e)}

def parse_pdf(file_path):
    """解析 PDF 文档"""
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(file_path)
        text = ""
        images = []
        
        for page in doc:
            text += page.get_text() + "\n\n"
            # 提取图片
            for img in page.get_images():
                xref = img[0]
                pix = fitz.Pixmap(doc, xref)
                if pix.n < 5:
                    img_data = pix.tobytes("png")
                    img_base64 = base64.b64encode(img_data).decode()
                    images.append(f"data:image/png;base64,{img_base64}")
        
        doc.close()
        return {"text": text, "images": images, "error": None}
    except Exception as e:
        return {"text": "", "images": [], "error": str(e)}

def parse_txt(file_path):
    """解析文本文件"""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            text = f.read()
        return {"text": text, "images": [], "error": None}
    except Exception as e:
        return {"text": "", "images": [], "error": str(e)}

# ========== AI 智能排版 ==========

def smart_layout(text):
    """智能排版处理"""
    lines = text.split('\n')
    processed = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # 标题识别
        if re.match(r'^第[一二三四五六七八九十]+[章节部]', line):
            processed.append(f"# {line}")
        elif re.match(r'^[一二三四五六七八九十]+[、.]', line):
            processed.append(f"## {line}")
        elif re.match(r'^\d+[\.\、]', line) and len(line) < 50:
            processed.append(f"### {line}")
        # 警示框识别
        elif re.match(r'^(危险|警告|注意|提示|DANGER|WARNING|NOTICE)[:：]', line, re.I):
            processed.append(line)
        # 列表识别
        elif re.match(r'^[-*•]\s', line):
            processed.append(line)
        elif re.match(r'^\d+\)\s', line):
            processed.append(f"- {line[3:]}")
        else:
            processed.append(line)
    
    return '\n'.join(processed)

def generate_toc(text):
    """生成目录"""
    toc = []
    lines = text.split('\n')
    
    for i, line in enumerate(lines):
        line = line.strip()
        match = re.match(r'^(#{1,4})\s+(.+)$', line)
        if match:
            level = len(match.group(1))
            title = match.group(2)
            toc.append({
                "level": level,
                "title": title,
                "line": i + 1
            })
    
    return toc

# ========== 路由 ==========

@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

@app.route('/api/import/feishu', methods=['POST'])
def import_feishu():
    """导入飞书文档"""
    data = request.json
    doc_id = data.get('doc_id')
    doc_type = data.get('doc_type', 'docx')
    
    if not doc_id:
        return jsonify({"error": "缺少文档ID"}), 400
    
    # 获取文档内容
    if doc_type == "docx":
        path = f"docx/v1/documents/{doc_id}/raw_content"
    else:
        path = f"docs/{doc_id}/raw_content"
    
    result, error = feishu_api(path)
    if error:
        return jsonify({"error": error}), 400
    
    content = result.get("content", "") if result else ""
    
    # 智能排版
    processed = smart_layout(content)
    toc = generate_toc(processed)
    
    return jsonify({
        "content": processed,
        "toc": toc,
        "doc_id": doc_id,
        "stats": {
            "chars": len(content),
            "lines": len(content.split('\n')),
            "sections": len(toc)
        }
    })

@app.route('/api/import/file', methods=['POST'])
def import_file():
    """导入本地文件"""
    if 'file' not in request.files:
        return jsonify({"error": "未上传文件"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "未选择文件"}), 400
    
    # 保存临时文件
    filename = secure_filename(file.filename)
    ext = filename.rsplit('.', 1)[-1].lower()
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(file_path)
    
    # 根据类型解析
    if ext == 'docx':
        result = parse_docx(file_path)
    elif ext == 'pdf':
        result = parse_pdf(file_path)
    elif ext in ['txt', 'md']:
        result = parse_txt(file_path)
    else:
        os.remove(file_path)
        return jsonify({"error": f"不支持的文件格式: {ext}"}), 400
    
    os.remove(file_path)
    
    if result["error"]:
        return jsonify({"error": result["error"]}), 400
    
    # 智能排版
    processed = smart_layout(result["text"])
    toc = generate_toc(processed)
    
    return jsonify({
        "content": processed,
        "images": result["images"],
        "toc": toc,
        "stats": {
            "chars": len(result["text"]),
            "lines": len(result["text"].split('\n')),
            "sections": len(toc),
            "images": len(result["images"])
        }
    })

@app.route('/api/layout/smart', methods=['POST'])
def layout_smart():
    """智能排版"""
    text = request.json.get('text', '')
    processed = smart_layout(text)
    toc = generate_toc(processed)
    
    return jsonify({
        "content": processed,
        "toc": toc
    })

@app.route('/api/toc/generate', methods=['POST'])
def toc_generate():
    """生成目录"""
    text = request.json.get('text', '')
    toc = generate_toc(text)
    return jsonify({"toc": toc})

@app.route('/api/version/save', methods=['POST'])
def version_save():
    """保存版本"""
    doc_id = request.json.get('doc_id', 'default')
    content = request.json.get('content', '')
    
    if doc_id not in VERSIONS:
        VERSIONS[doc_id] = []
    
    version = {
        "id": len(VERSIONS[doc_id]) + 1,
        "content": content,
        "time": datetime.now().isoformat(),
        "chars": len(content)
    }
    VERSIONS[doc_id].append(version)
    
    return jsonify({"version": version})

@app.route('/api/version/list', methods=['GET'])
def version_list():
    """版本列表"""
    doc_id = request.args.get('doc_id', 'default')
    versions = VERSIONS.get(doc_id, [])
    return jsonify({"versions": versions})

@app.route('/api/export/pdf', methods=['POST'])
def export_pdf():
    """导出 PDF"""
    content = request.json.get('content', '')
    title = request.json.get('title', '产品手册')
    
    # 生成 HTML
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{title}</title>
    <style>
        @page {{ size: A4; margin: 15mm; }}
        body {{ font-family: "Microsoft YaHei", Arial, sans-serif; line-height: 1.6; }}
        h1 {{ color: #0066cc; border-bottom: 2px solid #0066cc; padding-bottom: 5mm; }}
        h2 {{ color: #0066cc; }}
    </style>
</head>
<body>{content}</body>
</html>"""
    
    # 返回 HTML（前端用浏览器打印）
    return jsonify({"html": html, "title": title})

@app.route('/api/export/word', methods=['POST'])
def export_word():
    """导出 Word"""
    content = request.json.get('content', '')
    title = request.json.get('title', '产品手册')
    
    # 简单的 HTML 转 Word
    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>{title}</title></head>
<body>
<h1>{title}</h1>
{content}
</body>
</html>"""
    
    return jsonify({"html": html, "title": title})

@app.route('/api/feishu/publish', methods=['POST'])
def feishu_publish():
    """发布到飞书"""
    content = request.json.get('content', '')
    title = request.json.get('title', '产品手册')
    folder_token = request.json.get('folder_token')
    
    # 创建飞书文档
    data = {
        "title": title,
        "folder_token": folder_token
    }
    
    result, error = feishu_api("docx/v1/documents", "POST", data)
    if error:
        return jsonify({"error": error}), 400
    
    doc_id = result.get("document", {}).get("document_id")
    
    # 更新文档内容
    # TODO: 实现内容更新
    
    return jsonify({
        "doc_id": doc_id,
        "url": f"https://wbenergy.feishu.cn/docx/{doc_id}"
    })

if __name__ == '__main__':
    print("🚀 AI手册排版工具启动中...")
    print("📍 访问地址: http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)