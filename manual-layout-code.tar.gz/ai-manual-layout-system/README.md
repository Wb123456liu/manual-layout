# 📋 AI 产品手册排版系统

基于 OpenClaw 平台的手册智能排版系统，支持多区域、多产品类型的自动化排版和评审。

---

## 🎯 核心功能

### 1. 标准化输入
- ✅ JSON 模板提交需求
- ✅ 16 种区域 × 产品 × 手册组合
- ✅ 自动匹配排版规则

### 2. 智能排版
- ✅ 自动应用区域标准（GB/CE/UL/IEC）
- ✅ 封面/目录/安全标识/法律页
- ✅ 多语言支持

### 3. AI 评审
- ✅ 技术评审（参数/电路图/操作步骤）
- ✅ 安全评审（标识/认证/警告语）
- ✅ 本地化评审（翻译/单位/格式）
- ✅ P0/P1/P2 问题分级

### 4. 多格式输出
- ✅ PDF 打印版（300DPI, CMYK）
- ✅ PDF 浏览版（72DPI, RGB）
- ✅ IDML（InDesign 可编辑）
- ✅ HTML（预览用）

---

## 📁 项目结构

```
ai-manual-layout-system/
├── README.md                     # 本文档
├── integration_test.py           # 集成测试脚本
├── templates/                    # 需求模板
│   ├── request-template.json    # 标准模板
│   ├── 使用说明.md               # 模板使用说明
│   └── examples/                # 示例文件
│       ├── example-eu-dc-um.json
│       └── example-cn-ac-um.json
├── config/                       # 配置文件
│   └── review_rules.json        # 16 种组合规则
├── requests/                     # 需求文件（存放提交的 JSON）
├── output/                       # 输出文件
│   ├── REQ-xxx.html            # HTML 排版
│   ├── REQ-xxx.pdf             # PDF 输出
│   ├── REQ-xxx.idml            # IDML 输出
│   ├── REQ-xxx_review.md       # 评审报告
│   └── REQ-xxx_summary.md      # 总结报告
└── skills/                       # 核心技能
    ├── review-agent/            # 评审 Agent
    │   ├── SKILL.md
    │   ├── review_agent.py
    │   └── prompts/
    │       └── review_expert.md
    └── idml-generator/          # IDML 生成器
        ├── SKILL.md
        └── idml_generator.py
```

---

## 🚀 快速开始

### 步骤 1：填写需求

复制模板文件：

```bash
cp templates/request-template.json requests/REQ-20240323-001.json
```

修改必填字段：

```json
{
  "product": {
    "name": "产品名称",
    "model": "产品型号"
  },
  "classification": {
    "region": "EU",
    "product_type": "DC",
    "manual_type": "UM"
  },
  "contact": {
    "name": "联系人",
    "email": "邮箱"
  }
}
```

### 步骤 2：运行排版

```bash
python3 integration_test.py
```

### 步骤 3：查看输出

```bash
ls output/
# REQ-20240323-001.html
# REQ-20240323-001.pdf
# REQ-20240323-001.idml
# REQ-20240323-001_review.md
# REQ-20240323-001_summary.md
```

---

## 📊 配置说明

### 区域代码

| 代码 | 区域 | 标准 | 认证 |
|-----|------|------|------|
| CN | 中国大陆 | GB | CCC |
| EU | 欧洲 | IEC/ISO | CE |
| US | 北美 | UL/CSA | UL |
| SEA | 东南亚 | IEC | IEC |

### 产品类型代码

| 代码 | 类型 |
|-----|------|
| AC | 交流充电桩 |
| DC | 直流充电桩 |
| HS | 户用储能 |
| PCS | 储能变流器 |

### 手册类型代码

| 代码 | 类型 |
|-----|------|
| UM | 用户手册 |
| IM | 安装手册 |
| MM | 维护手册 |
| DS | 技术规格书 |

---

## 🧪 测试示例

运行集成测试：

```bash
python3 integration_test.py
```

**测试场景：** 欧洲区直流充电桩用户手册

**输出：**
- ✅ HTML 排版
- ✅ PDF 打印版
- ✅ IDML 可编辑版
- ✅ 评审报告（4 个问题）
- ✅ 总结报告

---

## 📝 需求模板字段

### 必填字段

| 字段路径 | 说明 | 示例 |
|---------|------|------|
| `product.name` | 产品名称 | "EVlink Pro DC 180" |
| `product.model` | 产品型号 | "GEX4301000" |
| `classification.region` | 销售区域 | "EU" |
| `classification.product_type` | 产品类型 | "DC" |
| `classification.manual_type` | 手册类型 | "UM" |
| `output.formats` | 输出格式 | ["PDF_Print", "IDML"] |
| `contact.name` | 联系人姓名 | "张三" |
| `contact.email` | 联系人邮箱 | "zhangsan@example.com" |

### 选填字段

| 字段路径 | 默认值 | 说明 |
|---------|--------|------|
| `product.version` | "v1.0" | 产品版本 |
| `output.language` | "auto" | 语言版本 |
| `source.type` | "feishu" | 文档来源 |
| `source.link` | - | 文档链接 |
| `priority` | "normal" | 优先级 |
| `deadline` | - | 截止时间 |

---

## 🤖 评审 Agent

### 检查范围

**技术检查（40%）：**
- 技术参数准确性
- 电路图/接线图正确性
- 操作步骤完整性
- 术语一致性

**安全检查（40%）：**
- 安全标识符合区域标准
- 警告语级别使用规范
- 认证标志使用正确

**本地化检查（20%）：**
- 翻译准确性
- 单位制式转换
- 日期/数字格式

### 问题分级

| 级别 | 说明 | 处理 |
|-----|------|------|
| P0 | 安全事故/违反法规/严重误导 | 必须修改，复审 |
| P1 | 影响理解/不专业/不符合标准 | 建议修改 |
| P2 | 格式小问题/可优化细节 | 可选修改 |

---

## 🛠️ 技术栈

| 功能 | 工具 |
|-----|------|
| 文档解析 | miaoda-doc-parse |
| 排版引擎 | manual-typesetting + style-kit |
| PDF 生成 | WeasyPrint v68.1 |
| IDML 生成 | idml-generator (自研) |
| 评审系统 | review-agent (自研) |
| 配置管理 | JSON |

---

## 📋 使用场景

### 场景 1：中国区产品手册

```json
{
  "classification": {
    "region": "CN",
    "product_type": "AC",
    "manual_type": "UM"
  },
  "output": {
    "formats": ["PDF_Print", "IDML"],
    "language": "zh-CN"
  }
}
```

### 场景 2：欧洲区多语言手册

```json
{
  "classification": {
    "region": "EU",
    "product_type": "DC",
    "manual_type": "UM"
  },
  "output": {
    "formats": ["PDF_Print", "IDML"],
    "language": "multi",
    "languages": ["en", "de", "fr", "es"]
  }
}
```

### 场景 3：北美区 UL 认证手册

```json
{
  "classification": {
    "region": "US",
    "product_type": "HS",
    "manual_type": "IM"
  },
  "output": {
    "formats": ["PDF_Print"],
    "language": "en"
  },
  "requirements": {
    "special": "需要符合 UL 标准，添加 UL 标志"
  }
}
```

---

## 📞 支持

- **模板使用：** 查看 `templates/使用说明.md`
- **配置规则：** 查看 `config/review_rules.json`
- **评审标准：** 查看 `skills/review-agent/prompts/review_expert.md`

---

## 🎯 下一步

1. ⏳ 用真实文档测试
2. ⏳ 优化评审 Agent 准确率
3. ⏳ 完善 IDML 生成器（图片/表格支持）
4. ⏳ 部署上线

---

**版本：** v1.0  
**更新时间：** 2024-03-23  
**制作者：** AI 排版系统
